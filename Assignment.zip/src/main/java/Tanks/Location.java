package Tanks;

public interface Location {
    int getX();
    int getY();
    void setX(int x);
    void setY(int y);
}
